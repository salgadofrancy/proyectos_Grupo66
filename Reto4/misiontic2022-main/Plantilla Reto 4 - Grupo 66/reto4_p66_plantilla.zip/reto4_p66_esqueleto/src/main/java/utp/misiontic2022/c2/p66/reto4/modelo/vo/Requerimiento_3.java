package utp.misiontic2022.c2.p66.reto4.modelo.vo;

public class Requerimiento_3 {

    // Por hacer

}
